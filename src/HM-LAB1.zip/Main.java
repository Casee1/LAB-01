import java.math.BigInteger;

public class Main {
    public static void main(String[] args) {
/*CHESS BOARD
        BigInteger myInt = new BigInteger("2");

        int i=0;

        myInt=myInt.pow(i);

        System.out.println(myInt);
*/
/*ADD 1 TO MAX VALUE
        int myInt = Integer.MAX_VALUE;
        float myFloat = Float.MAX_VALUE;
        double myDouble = Double.MAX_VALUE;
        long myLong = Long.MAX_VALUE;

        System.out.println(myInt +"\n"+ myFloat +"\n"+ myDouble +"\n"+ myLong);

        System.out.println();

        myInt = myInt+1;
        myFloat = myFloat+1.0f;
        myDouble = myDouble+1.0d;
        myLong = myLong+1;

        System.out.println(myInt +"\n"+ myFloat +"\n"+ myDouble +"\n"+ myLong);
*/
/*SUBSTRACT 1 FROM MAX VALUE
        int myInt = Integer.MAX_VALUE;
        float myFloat = Float.MAX_VALUE;
        double myDouble = Double.MAX_VALUE;
        long myLong = Long.MAX_VALUE;

        System.out.println(myInt +"\n"+ myFloat +"\n"+ myDouble +"\n"+ myLong);

        System.out.println();

        myInt = myInt-1;
        myFloat = myFloat-1.0f;
        myDouble = myDouble-1.0d;
        myLong = myLong-1;

        System.out.println(myInt +"\n"+ myFloat +"\n"+ myDouble +"\n"+ myLong);
*/
/*MORE DECIMALS THAN MAX; DECIMALS WILL NOT BE COUNTED IF MORE THAN MAX
        float decimalf = 0.12315124121252155712684721648126589f;
        double decimald = 0.51827419827519258023985029859372409823095823097523053285094;

        System.out.println(decimalf + " " + decimald);
*/
/*ADD TO A FLOATING POINT NUMBER A NUMBER WITH MORE DECIMALS
  WE SEE THAT IT ONLY ADDS UP TO THE AMX NUMBER OF DECIMALS
        float decimalf = 0.1f;
        double decimald = 0.5;

        decimalf = decimalf + 0.124901275981275498127498275819579182f;
        decimald = decimald + 0.12371624982175719587394729857230987502938509237502937502375029;

        System.out.println(decimalf + " " + decimald);


*/
    }
}